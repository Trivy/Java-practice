package garage;

public enum TypeMoteur {
	DIESEL, ESSENCE, HYBRIDE, ELECTRIQUE;
}
