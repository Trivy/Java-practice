package garage;

import java.io.Serializable;

public enum Marque implements Serializable{
	RENO,PIGEOT,TROEN;
}
