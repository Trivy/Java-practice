package garage;

public interface Option{
	double getPrix();
}
